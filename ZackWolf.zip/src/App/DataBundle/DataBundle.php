<?php

namespace App\DataBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DataBundle extends Bundle
{
}
